﻿POKEMON VORTEX NXT CLIENT

START PLAYING
1. Extract the entire Windows client ZIP to a permanent folder.
2. Open PokemonVortexNXT.exe.
3. If prompted, install Microsoft Edge WebView2 Evergreen Runtime using
   the Microsoft setup link, then reopen the client.
4. Start your Pokemon Vortex web server and log in normally.

Default game address: http://127.0.0.1/PokemonVortex/
127.0.0.1 means the PC running this client. To join another server, open
Options > Advanced · game server and save its reachable game base address.
The client saves this choice and keeps browser sessions separate by server.
No server, database, or game installation is bundled.

CONTROLS
Home: return to the landing page. Back is disabled at the landing page.
Reload: refresh the current page.
F11 or Alt+Enter: toggle fullscreen. Escape leaves fullscreen.
Options: saved client mute and zoom preferences.

Sound and browser autoplay are enabled by default. The game's own saved
music/effects settings still apply. Client mute silences the entire client.
If the game waits for a click before playing audio, click inside the game.

DESKTOP SHORTCUT
Run Install Desktop Shortcut.cmd beside the EXE after choosing a permanent
folder. It replaces any existing Pokemon Vortex NXT desktop shortcut from
the earlier launcher. Keep the entire client folder in that location.

IF THE GAME WILL NOT LOAD
Check the server is running, the saved address is correct, and any required
network or VPN connection is active. On another PC, 127.0.0.1 will not reach
your friend's server: use the reachable address they provide.
External navigation and downloads are blocked. Allowed game popup links
open in the existing game window.

KEEP EVERY FILE IN THE EXTRACTED FOLDER
The EXE needs its accompanying files. Visual Studio and a separate .NET
installation are not needed; WebView2 Evergreen Runtime is required.

The client compiled and published successfully. Actual Windows launch,
audio, and live-game behavior still need checking on your installation.
